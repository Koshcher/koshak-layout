# Koshak AutoHotKey Script
This AutoHotKey script is designed for when you want Koshak on Windows, but can not install it system-wide. For example, you are a standard user on a public computer.

You need https://autohotkey.com for this script.