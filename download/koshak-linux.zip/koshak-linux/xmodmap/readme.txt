Go directory where you have unpacked Koshak
Type: setxkbmap us; xmodmap xmodmap/xmodmap.koshak && xset r 66
To switch back to QWERTY type: setxkbmap us; xset -r 66